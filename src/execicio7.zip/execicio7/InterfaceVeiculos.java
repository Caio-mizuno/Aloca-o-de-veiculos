/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package execicio7;

/**
 *
 * @author Caio
 */
public interface InterfaceVeiculos {
    public abstract void abrirMenu();
    public abstract void ligar();
    public abstract void desligar();
    public abstract void virar();
    public abstract void acelerar();
    public abstract void frear();
    public abstract void trocarMarcha(int marcha);    
}
